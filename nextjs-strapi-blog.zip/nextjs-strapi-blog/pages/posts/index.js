import React from 'react';
import axios from 'axios'

import AllPosts from '../../components/AllPosts';

// Elements
import { Container,Col,Row } from 'react-bootstrap'

const Post = ({posts}) => {
    return (
        <>
            This is my Post Page


            <Container className='mt-5'>
              <Row>
                  <AllPosts posts={posts} />
              </Row>
            </Container>
            
            
        </>
    )
}

export default Post;


// This gets called on every request
export async function getServerSideProps() {
    // const postsResult = await axios.get('http://localhost:1337/api/posts');
    const postsResult = await axios.get('http://localhost:1337/api/posts?populate=image');
    
    return {
      props: {
        posts: postsResult.data
        
      }
    }
}
  