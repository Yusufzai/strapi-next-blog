import React, { useEffect, useState } from 'react';
import BSCard from './Card';
import { Col } from 'react-bootstrap'

const HomeLatestPosts = ({ posts }) => {
    const [latestPosts, setLatestPosts] = useState([]);
    
    useEffect(() => {
        // const p = posts.slice(0, 5)
        setLatestPosts(posts.data.slice(0, 5));
    }, [posts]);

    function renderPostPreview() {
        return latestPosts.map((post) => {
            // console.log(post)
            // console.log(post.id)
            return <Col xl={3} lg={4} sm={3}> <BSCard postTitle={post.attributes.title} postText={post.attributes.content} id={post.id} /></Col>
            
        })
    }
    
    
    return (
        <>
            <h1>Latest Post</h1>

            {/* {console.log(posts.data)} */}
            {/* {console.log(posts)} */}
            {/* {console.log(posts.data.slice(0, 2))} */}
            {renderPostPreview()}
        </>
    )
}

export default HomeLatestPosts;