import Link from 'next/link';
import React from 'react';
import { Navbar } from 'react-bootstrap'
import { Container } from 'react-bootstrap'
import { Nav } from 'react-bootstrap'

const NavBar = () => {
    return (
        <>
            <Navbar bg="dark" variant="dark">
                <Container>
                    <Link href="/">
                        <a className="navbar-brand">Navbar</a>
                    </Link>
                    <Nav className="me-auto">
                        <Link href="/posts" className="nav-link">
                            <a className="nav-link">All Posts</a>
                            {/* <Nav.Link href="#home">Home</Nav.Link> */}
                        </Link>
                        {/* <Nav.Link href="#home">Home</Nav.Link> */}
                        {/* <Nav.Link href="#features">Features</Nav.Link> */}
                        {/* <Nav.Link href="#pricing">Pricing</Nav.Link> */}
                    </Nav>
                </Container>
            </Navbar>
        </>
    )
}

export default NavBar;