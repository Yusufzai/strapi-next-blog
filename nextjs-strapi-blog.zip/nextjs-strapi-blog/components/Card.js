import React from 'react';
import Link from 'next/link';
import { Card } from 'react-bootstrap'
import { Button } from 'react-bootstrap'

const BSCard = (props) => {
    return (
        <>

            <Link href={`/posts/${props.id}`}>
                <Card id={props.id} style={{ width: '18rem' }}>
                    {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                    <Card.Body>
                        <Card.Title>{props.postTitle}</Card.Title>
                        <Card.Text>
                            {props.postText}
                        </Card.Text>
                        <Button variant="primary">Go somewhere</Button>
                    </Card.Body>
                </Card>
            </Link>
        </>
    )
}

export default BSCard;