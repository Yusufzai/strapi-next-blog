import React from 'react';

const HomeHeader = () => {
    return (
        <>
            <h1>Welcome to my Blog Home Page</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus feugiat odio tortor, sed ullamcorper libero tincidunt eu. Phasellus dolor justo, pharetra ut lectus id, maximus placerat diam. Morbi tortor dui, scelerisque eu urna at, congue ullamcorper erat. Vivamus tempus ex consectetur leo accumsan, et cursus eros semper. Nulla tempor nibh id dolor molestie, eget ornare nunc vehicula. Cras imperdiet magna quis nibh placerat vestibulum. Maecenas tellus metus, elementum non sodales eu, faucibus vitae nibh. Vestibulum placerat velit fringilla augue consequat semper. Donec nec lectus ac erat consectetur malesuada ut eget purus.</p>
        </>
    )
}

export default HomeHeader;