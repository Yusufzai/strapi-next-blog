const init = (initialState, fieldsToPick) => {
  return { ...initialState, fieldsToPick };
};

export default init;
