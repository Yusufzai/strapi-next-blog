const basename = process.env.ADMIN_PATH.replace(window.location.origin, '');

export default basename;
