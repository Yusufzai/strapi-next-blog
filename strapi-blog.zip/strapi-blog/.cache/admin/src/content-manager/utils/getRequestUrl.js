// FIXME when back-end ready
const getRequestUrl = path => `/content-manager/${path}`;

export default getRequestUrl;
