import { createContext } from 'react';

const ContentTypeLayout = createContext();

export default ContentTypeLayout;
