const validationsToOmit = [
  'type',
  'model',
  'via',
  'collection',
  'default',
  'plugin',
  'enum',
  'regex',
  'pluginOptions',
];

export default validationsToOmit;
