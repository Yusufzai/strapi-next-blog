const UID_REGEX = new RegExp(/^[A-Za-z0-9-_.~]*$/);

export default UID_REGEX;
