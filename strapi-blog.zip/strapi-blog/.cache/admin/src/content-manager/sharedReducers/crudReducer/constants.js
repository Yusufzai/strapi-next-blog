export const GET_DATA = 'ContentManager/CrudReducer/GET_DATA';
export const GET_DATA_SUCCEEDED = 'ContentManager/CrudReducer/GET_DATA_SUCCEEDED';
export const INIT_FORM = 'ContentManager/CrudReducer/INIT_FORM';
export const RESET_PROPS = 'ContentManager/CrudReducer/RESET_PROPS';
export const SET_DATA_STRUCTURES = 'ContentManager/CrudReducer/SET_DATA_STRUCTURES';
export const SET_STATUS = 'ContentManager/CrudReducer/SET_STATUS';
export const SUBMIT_SUCCEEDED = 'ContentManager/CrudReducer/SUBMIT_SUCCEEDED';
